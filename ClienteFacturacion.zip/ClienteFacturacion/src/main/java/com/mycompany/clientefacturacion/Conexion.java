package com.mycompany.clientefacturacion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    // Datos de tu base de datos Oracle
    private static final String URL = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
    private static final String USUARIO = "jennifer"; 
    private static final String CLAVE = "Papeleria123"; 

    public static Connection conectar() {
        Connection con = null;
        try {
            // Cargar el driver de Oracle
            Class.forName("oracle.jdbc.OracleDriver");
            // Intentar conectar
            con = DriverManager.getConnection(URL, USUARIO, CLAVE);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error: No se encontró el driver. Revisa el pom.xml o las Dependencies.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error de conexión a Oracle: " + e.getMessage());
        }
        return con;
    }
}