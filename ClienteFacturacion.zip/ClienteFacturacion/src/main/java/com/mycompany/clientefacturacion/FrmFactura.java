package com.mycompany.clientefacturacion;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;

public class FrmFactura extends javax.swing.JFrame {

    // Paleta de colores
    private static final Color AZUL_OSCURO = new Color(9, 48, 89);
    private static final Color VERDE_CABECERA = new Color(33, 150, 83);
    private static final Color FONDO = new Color(248, 251, 255);
    private static final Color BLANCO = Color.WHITE;
    private static final Color GRIS = new Color(100, 115, 130);
    private static final Color AZUL_BOTON = new Color(20, 125, 235);

    // Componentes
    private JTextField txtNumFactura;
    private JTextField txtFecha;
    private JComboBox<String> cbCliente;
    private JComboBox<String> cbCiudad;
    private JComboBox<String> cbArticulo;
    private JTextField txtCantidad;
    private JTable tblDetalle;
    private DefaultTableModel modelo;
    private JLabel lblTotal;

    public FrmFactura() {
        setTitle("Facturación - Nueva Factura");
        setSize(1000, 700);
        setMinimumSize(new Dimension(900, 650));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        inicializarComponentes();
        cargarDatosIniciales();
    }

    private void inicializarComponentes() {
        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(FONDO);

        // ==========================================
        // 1. ENCABEZADO (Título)
        // ==========================================
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(FONDO);
        encabezado.setBorder(new EmptyBorder(20, 30, 10, 30));

        JLabel titulo = new JLabel("Nueva Factura");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(VERDE_CABECERA);
        
        JLabel subtitulo = new JLabel("Registra una nueva venta en el sistema.");
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitulo.setForeground(GRIS);

        JPanel panelTitulos = new JPanel();
        panelTitulos.setOpaque(false);
        panelTitulos.setLayout(new BoxLayout(panelTitulos, BoxLayout.Y_AXIS));
        panelTitulos.add(titulo);
        panelTitulos.add(Box.createVerticalStrut(5));
        panelTitulos.add(subtitulo);

        encabezado.add(panelTitulos, BorderLayout.WEST);
        principal.add(encabezado, BorderLayout.NORTH);

        // ==========================================
        // 2. CUERPO (Formulario y Tabla)
        // ==========================================
        JPanel cuerpo = new JPanel(new BorderLayout(0, 20));
        cuerpo.setBackground(FONDO);
        cuerpo.setBorder(new EmptyBorder(10, 30, 20, 30));

        // --- A. Formulario Cabecera ---
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Fila 1: N° Factura y Fecha
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
        panelFormulario.add(new JLabel("N° Factura:"), gbc);
        txtNumFactura = new JTextField();
        txtNumFactura.setEditable(false); // Se genera solo
        txtNumFactura.setFont(new Font("Segoe UI", Font.BOLD, 14));
        gbc.gridx = 1; gbc.gridy = 0;
        panelFormulario.add(txtNumFactura, gbc);

        gbc.gridx = 2; gbc.gridy = 0;
        panelFormulario.add(new JLabel("Fecha:"), gbc);
        txtFecha = new JTextField();
        txtFecha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 3; gbc.gridy = 0;
        panelFormulario.add(txtFecha, gbc);

        // Fila 2: Cliente y Ciudad
        gbc.gridx = 0; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Cliente:"), gbc);
        cbCliente = new JComboBox<>();
        cbCliente.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 1; gbc.gridy = 1;
        panelFormulario.add(cbCliente, gbc);

        gbc.gridx = 2; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Ciudad:"), gbc);
        cbCiudad = new JComboBox<>();
        cbCiudad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 3; gbc.gridy = 1;
        panelFormulario.add(cbCiudad, gbc);

        cuerpo.add(panelFormulario, BorderLayout.NORTH);

        // --- B. Panel Detalle (Tabla y controles) ---
        JPanel panelDetalle = new JPanel(new BorderLayout(0, 10));
        panelDetalle.setOpaque(false);

        // Controles para agregar artículo
        JPanel panelAgregar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelAgregar.setOpaque(false);
        
        panelAgregar.add(new JLabel("Artículo:"));
        cbArticulo = new JComboBox<>();
        cbArticulo.setPreferredSize(new Dimension(250, 30));
        cbArticulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panelAgregar.add(cbArticulo);
        
        panelAgregar.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField(5);
        txtCantidad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panelAgregar.add(txtCantidad);
        
        JButton btnAgregar = new JButton("+ Agregar Artículo");
        btnAgregar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnAgregar.setForeground(BLANCO);
        btnAgregar.setBackground(AZUL_BOTON);
        btnAgregar.setFocusPainted(false);
        btnAgregar.setBorder(new EmptyBorder(8, 15, 8, 15));
        btnAgregar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panelAgregar.add(btnAgregar);

        panelDetalle.add(panelAgregar, BorderLayout.NORTH);

        // Tabla
        modelo = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        modelo.addColumn("Código");
        modelo.addColumn("Artículo");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Precio Unit.");
        modelo.addColumn("Subtotal");

        tblDetalle = new JTable(modelo);
        tblDetalle.setRowHeight(35);
        tblDetalle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tblDetalle.setShowVerticalLines(false);
        tblDetalle.setGridColor(new Color(232, 239, 247));
        tblDetalle.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        tblDetalle.getTableHeader().setBackground(new Color(240, 246, 252));
        tblDetalle.getTableHeader().setForeground(AZUL_OSCURO);
        tblDetalle.getTableHeader().setPreferredSize(new Dimension(0, 40));

        JScrollPane scroll = new JScrollPane(tblDetalle);
        scroll.setBorder(new LineBorder(new Color(214, 230, 244), 1, true));
        scroll.getViewport().setBackground(BLANCO);

        panelDetalle.add(scroll, BorderLayout.CENTER);
        cuerpo.add(panelDetalle, BorderLayout.CENTER);

        principal.add(cuerpo, BorderLayout.CENTER);

        // ==========================================
        // 3. PIE DE PÁGINA (Total, Guardar y Regresar)
        // ==========================================
        JPanel panelPie = new JPanel(new BorderLayout());
        panelPie.setBackground(FONDO);
        panelPie.setBorder(new EmptyBorder(10, 30, 20, 30));

        // Botón Regresar (Izquierda)
        JButton btnRegresar = new JButton("<< Regresar al menú");
        btnRegresar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnRegresar.setForeground(AZUL_OSCURO);
        btnRegresar.setContentAreaFilled(false);
        btnRegresar.setBorderPainted(false);
        btnRegresar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRegresar.addActionListener(e -> dispose());

        // Total (Centro-Derecha)
        lblTotal = new JLabel("TOTAL: $0.00");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTotal.setForeground(VERDE_CABECERA);
        lblTotal.setHorizontalAlignment(SwingConstants.RIGHT);

        // Botón Guardar (Derecha)
        JButton btnGuardar = new JButton("GUARDAR FACTURA");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnGuardar.setForeground(BLANCO);
        btnGuardar.setBackground(VERDE_CABECERA);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(new EmptyBorder(12, 25, 12, 25));
        btnGuardar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JPanel panelDerechaPie = new JPanel(new BorderLayout(20, 0));
        panelDerechaPie.setOpaque(false);
        panelDerechaPie.add(lblTotal, BorderLayout.CENTER);
        panelDerechaPie.add(btnGuardar, BorderLayout.EAST);

        panelPie.add(btnRegresar, BorderLayout.WEST);
        panelPie.add(panelDerechaPie, BorderLayout.EAST);

        principal.add(panelPie, BorderLayout.SOUTH);

        setContentPane(principal);

        // ==========================================
        // 4. EVENTOS Y LÓGICA
        // ==========================================
        
        // Botón Agregar
        btnAgregar.addActionListener(e -> agregarArticulo());

        // Botón Guardar
        btnGuardar.addActionListener(e -> guardarFactura());
    }

    // ==========================================
    // 5. MÉTODOS DE BASE DE DATOS
    // ==========================================

    private void cargarDatosIniciales() {
        // Poner fecha actual
        java.text.SimpleDateFormat formato = new java.text.SimpleDateFormat("dd/MM/yyyy");
        txtFecha.setText(formato.format(new java.util.Date()));

        try {
            java.sql.Connection con = Conexion.conectar();
            java.sql.Statement st = con.createStatement();

            // Cargar Clientes
            java.sql.ResultSet rsC = st.executeQuery("SELECT ruc, nombre FROM jennifer.CLIENTE ORDER BY nombre");
            while (rsC.next()) {
                cbCliente.addItem(rsC.getString("ruc") + " - " + rsC.getString("nombre"));
            }

            // Cargar Ciudades
            java.sql.ResultSet rsCi = st.executeQuery("SELECT codigo, nombre FROM jennifer.CIUDAD ORDER BY nombre");
            while (rsCi.next()) {
                cbCiudad.addItem(rsCi.getString("codigo") + " - " + rsCi.getString("nombre"));
            }

            // Cargar Artículos
            java.sql.ResultSet rsA = st.executeQuery("SELECT codigo, nombre, precio FROM jennifer.ARTICULO ORDER BY nombre");
            while (rsA.next()) {
                cbArticulo.addItem(rsA.getString("codigo") + " - " + rsA.getString("nombre"));
            }

            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar listas: " + e.getMessage());
        }
    }

    private void agregarArticulo() {
        if (cbArticulo.getSelectedItem() == null || txtCantidad.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un artículo y escriba la cantidad.");
            return;
        }

        try {
            String seleccion = cbArticulo.getSelectedItem().toString();
            String codigoArticulo = seleccion.split(" - ")[0];
            int cantidad = Integer.parseInt(txtCantidad.getText());

            java.sql.Connection con = Conexion.conectar();
            java.sql.PreparedStatement pst = con.prepareStatement("SELECT nombre, precio FROM jennifer.ARTICULO WHERE codigo = ?");
            pst.setString(1, codigoArticulo);
            java.sql.ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String nombreArticulo = rs.getString("nombre");
                double precio = rs.getDouble("precio");
                double subtotal = precio * cantidad;

                Object[] fila = new Object[5];
                fila[0] = codigoArticulo;
                fila[1] = nombreArticulo;
                fila[2] = cantidad;
                fila[3] = precio;
                fila[4] = subtotal;
                modelo.addRow(fila);

                calcularTotal();
                txtCantidad.setText("");
                txtCantidad.requestFocus();
                con.close();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "La cantidad debe ser un número.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void calcularTotal() {
        double total = 0;
        for (int i = 0; i < modelo.getRowCount(); i++) {
            Object sub = modelo.getValueAt(i, 4);
            if (sub != null) total += Double.parseDouble(sub.toString());
        }
        lblTotal.setText("TOTAL: $" + String.format("%.2f", total));
    }

    private void guardarFactura() {
        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "Debe agregar al menos un artículo.");
            return;
        }
        if (cbCliente.getSelectedItem() == null || cbCiudad.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente y una ciudad.");
            return;
        }

        try {
            java.sql.Connection con = Conexion.conectar();
            
            String clienteRuc = cbCliente.getSelectedItem().toString().split(" - ")[0];
            String ciudadCodigo = cbCiudad.getSelectedItem().toString().split(" - ")[0];
            
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
            java.sql.Date fechaSql = new java.sql.Date(sdf.parse(txtFecha.getText()).getTime());
            
            String totalStr = lblTotal.getText().replace("TOTAL: $", "").replace(",", ".");
            double totalFactura = Double.parseDouble(totalStr);

            // Insertar Cabecera y Recuperar Número
            String sqlCab = "BEGIN INSERT INTO jennifer.FACTURA_CAB (fecha, ciudad_codigo, cliente_ruc, total) " +
                            "VALUES (?, ?, ?, ?) RETURNING numero INTO ?; END;";
            java.sql.CallableStatement cs = con.prepareCall(sqlCab);
            cs.setDate(1, fechaSql);
            cs.setString(2, ciudadCodigo);
            cs.setString(3, clienteRuc);
            cs.setDouble(4, totalFactura);
            cs.registerOutParameter(5, java.sql.Types.VARCHAR);
            cs.execute();
            
            String numFacturaGenerado = cs.getString(5);

            // Insertar Detalle
            String sqlDet = "INSERT INTO jennifer.FACTURA_DET (factura_numero, articulo_codigo, cantidad, precio) VALUES (?, ?, ?, ?)";
            java.sql.PreparedStatement pstDet = con.prepareStatement(sqlDet);
            
            for (int i = 0; i < modelo.getRowCount(); i++) {
                pstDet.setString(1, numFacturaGenerado);
                pstDet.setString(2, modelo.getValueAt(i, 0).toString());
                pstDet.setInt(3, Integer.parseInt(modelo.getValueAt(i, 2).toString()));
                pstDet.setDouble(4, Double.parseDouble(modelo.getValueAt(i, 3).toString()));
                pstDet.executeUpdate();
            }

            // INTEGRACIÓN CON CONTABILIDAD
            try {
                String sqlComp = "BEGIN INSERT INTO COMPROBANTE_CONTABLE (FECHA, OBSERVACIONES) VALUES (?, ?) RETURNING ID_COMPROBANTE INTO ?; END;";
                java.sql.CallableStatement csComp = con.prepareCall(sqlComp);
                csComp.setDate(1, fechaSql);
                csComp.setString(2, "Venta Factura " + numFacturaGenerado);
                csComp.registerOutParameter(3, java.sql.Types.INTEGER);
                csComp.execute();
                int idComprobante = csComp.getInt(3);

                int idCaja = 0, idVentas = 0;
                java.sql.Statement stC = con.createStatement();
                java.sql.ResultSet rsC = stC.executeQuery("SELECT CODIGO, ID_CUENTA FROM CUENTA_CONTABLE WHERE CODIGO IN ('1.1.01', '4.1.01')");
                while(rsC.next()) {
                    if(rsC.getString("CODIGO").equals("1.1.01")) idCaja = rsC.getInt("ID_CUENTA");
                    if(rsC.getString("CODIGO").equals("4.1.01")) idVentas = rsC.getInt("ID_CUENTA");
                }

                String sqlDetC = "INSERT INTO DETALLE_CONTABLE (ID_COMPROBANTE, ID_CUENTA, DEBE, HABER) VALUES (?, ?, ?, ?)";
                java.sql.PreparedStatement pstC = con.prepareStatement(sqlDetC);
                
                pstC.setInt(1, idComprobante); pstC.setInt(2, idCaja); pstC.setDouble(3, totalFactura); pstC.setDouble(4, 0); pstC.executeUpdate();
                pstC.setInt(1, idComprobante); pstC.setInt(2, idVentas); pstC.setDouble(3, 0); pstC.setDouble(4, totalFactura); pstC.executeUpdate();
                pstC.close();
            } catch (Exception exCont) {
                System.out.println("No se pudo integrar con contabilidad: " + exCont.getMessage());
            }

            JOptionPane.showMessageDialog(null, "¡Factura " + numFacturaGenerado + " guardada con éxito!");

            // Limpiar pantalla
            txtNumFactura.setText("");
            modelo.setRowCount(0);
            lblTotal.setText("TOTAL: $0.00");
            
            pstDet.close();
            con.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al guardar factura: " + e.getMessage());
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new FrmFactura().setVisible(true);
        });
    }
}